<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Insert data</title>
</head>
<body>
    <form action="/save" method="get">
        <table border="1" cellspacing="0" cellpadding="5">
            <tr>
                <th>Name</th>
                <td><input type="text" name="name"></td>
            </tr>
            <tr>
                <th>Mobile</th>
                <td><input type="text" name="mobile"></td>
            </tr>
            <tr>
                <th>Address</th>
                <td><textarea name="address" cols="20" rows="5"></textarea></td>
            </tr>
            <tr>
                <td colspan=2><input type="submit" value="Save" name="save"></td>
            </tr>
        </table>
    </form>
</body>
</html>