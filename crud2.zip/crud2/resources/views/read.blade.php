<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>show data</title>
</head>
<body>
    <table border="1" width="500" cellspacing="0"  cellpading="5">
        <thead>
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Mobile</th>
                <th>Address</th>
                <th>Action</th>
            </tr>
            <?php
            foreach($crud as $man){
            ?>
            <tr>
                <td><?=$man->id;?></td>
                <td><?=$man->name;?></td>
                <td><?=$man->mobile;?></td>
                <td><?=$man->address;?></td>
                <td><a href="/edit/<?=$man->id;?>">Edit</a>&nbsp;&nbsp;<a href="/delete/<?=$man->id?>">Delete</a></td>
            </tr>
            <?php
            }
            ?>
            <tr>
                <td colspan="5"><a href="/insert">Add new man</a></td>
            </tr>
        </thead>
    </table>
</body>
</html>