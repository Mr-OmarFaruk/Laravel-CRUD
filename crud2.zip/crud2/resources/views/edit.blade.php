<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update data</title>
</head>
<body>
    <form action="/process" method="get">
        <table border="1" cellspacing="0" cellpadding="5">
            <tr>
                <th>Name</th>
                <td><input type="text" name="name" value="<?=$man->name;?>"></td>
            </tr>
            <tr>
                <th>Mobile</th>
                <td><input type="text" name="mobile" value="<?=$man->mobile;?>"></td>
            </tr>
            <tr>
                <th>Address</th>
                <td><textarea name="address" cols="20" rows="5"><?=$man->address;?></textarea></td>
            </tr>
            <tr>
                <td><input type="submit" value="Save" name="save">
                <input type="hidden" name="id" value="<?=$man->id;?>"></td>
            </tr>
        </table>
    </form>
</body>
</html>