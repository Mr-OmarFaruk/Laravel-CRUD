<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class mycontroller extends Controller
{
    public function show(){
        $data=DB::table('crud')->get();
        return view('read',['crud'=>$data]);
    }
    public function edit($id){
        $data=DB::table('crud')->where('id',$id)->first();
        return view('edit',["man"=>$data]);
    }
    public function update(Request $request){
        $data=DB::table('crud')->where('id',$request->id)->update(['name'=>$request->name,'mobile'=>$request->mobile,'address'=>$request->address]);
        if($data){
            return redirect("/read");
        }
        else{
            echo"Upadate fail";
        }
    }
     public function save(Request $request){
        $data=DB::table('crud')->insert(['name'=>$request->name,'mobile'=>$request->mobile,'address'=>$request->address]);
        if($data){
            return redirect("/read");
        }
        else{
            echo"Insert fail";
        }
    }
    public function insert(){
        return view('insert');
    }
    public function delete($id){
        $data=DB::table('crud')->where('id',$id)->delete();
        if($data){
            return redirect("/read");
        }
        else{
            echo"Delete fail";
        }
    }
}
